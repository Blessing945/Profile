var typed = new typed(".text", {
    Strings:["Frontend Developer", "Web Developer", "Mobile_App Developer", "Backend Developer"],
    typeSpeed:100,
    backSpeed:100,
    backDelay: 1000,
    loop:true
})